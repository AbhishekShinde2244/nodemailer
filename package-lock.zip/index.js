const express = require('express');
const cors = require('cors');
const nodemailer = require('nodemailer');
const fs = require('fs');
const path = require('path');
require('dotenv').config();
const axios = require('axios');


const app = express();
const PORT = 3000;

app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Serve static files (e.g., your form HTML)
app.use(express.static(path.join(__dirname, 'public')));

// Load email HTML template once at startup
const htmlPath = path.join(__dirname, 'mail.html');
let htmlTemplate = fs.readFileSync(htmlPath, 'utf8');


app.post('/auth', async (req, res) => {
  const { email, appPassword } = req.body;

  const transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
      user: email,
      pass: appPassword,
    }
  });

  try {
    // Use verify to test credentials (no email sent)
    await transporter.verify();
    res.json({ success: true });
  } catch (err) {
    console.error("Gmail auth failed:", err);
    res.json({ success: false });
  }
});



app.post('/send', async (req, res) => {
  const { sendername, desg, admin, auth, recipients } = req.body;

  if (!sendername || !desg || !admin || !auth || !Array.isArray(recipients)) {
    return res.status(400).json({ error: "Missing required fields." });
  }

  try {
    const transporter = nodemailer.createTransport({
      service: 'gmail', // Adjust as needed
      auth: {
        user: admin,
        pass: auth,
      },
    });

    // Send emails individually
    const results = await Promise.all(recipients.map(async ({ clientName, email }) => {
      const htmlContent = htmlTemplate
        .replace('{{clientName}}', clientName)
        .replace('{{sendername}}', sendername)
        .replace('{{desg}}', desg);

      const info = await transporter.sendMail({
        from: admin,
        to: email,
        subject: `Hello ${clientName} from Node.js`,
        html: htmlContent,
      });

      return { email, messageId: info.messageId };
    }));

    res.json({ message: "All emails sent.", results });
  } catch (error) {
    console.error("Email send error:", error);
    res.status(500).json({ error: "Failed to send one or more emails." });
  }
});



//email verifier
app.get('/verify', async (req, res) => {
  const email = req.query.email;
  const apiKey = process.env.HUNTER_API_KEY;

  if (!email) {
    return res.status(400).json({ error: 'Email query parameter is required' });
  }

  try {
    const response = await axios.get('https://api.hunter.io/v2/email-verifier', {
      params: {
        email: email,
        api_key: apiKey,
      },
    });

    res.json({
      email: response.data.data.email,
      result: response.data.data.result, // deliverable, risky, etc.
      score: response.data.data.score,
      first_name: response.data.data.first_name,
      last_name: response.data.data.last_name,
      domain: response.data.data.domain,
    });
  } catch (error) {
    console.error('Hunter API error:', error.message);
    res.status(500).json({ error: 'Failed to verify email' });
  }
});



app.get('/verify2', async (req, res) => {
  const email = req.query.email;
  const apiKey = process.env.ABSTRACT_API_KEY;

  if (!email) {
    return res.status(400).json({ error: 'Email query parameter is required' });
  }
  const axios = require('axios');
              axios.get(`https://emailvalidation.abstractapi.com/v1/?api_key=${apiKey}&email=${email}`)
                  .then(response => {
                      console.log(response.data);
                  })
                  .catch(error => {
                      console.log(error);
                  });
  });

app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
